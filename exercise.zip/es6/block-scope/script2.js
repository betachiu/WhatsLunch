﻿function f() {
    var text = "1";
}
console.log(text); // error

function f2() {
    let text2 = "1";
}
console.log(text2); // error

if(true) {
    var text3 = "1";
}
console.log(text3); // 1

if(true) {
    let text4 = "1";
}
console.log(text4); // error