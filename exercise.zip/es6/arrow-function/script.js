﻿const func = function() { 
  console.log('我是普通函式'); 
}; 
  
const arrowFunc = () => { 
  console.log('我是箭頭函式'); 
}; 
  
const add = (a, b) => { 
  return a + b; 
}; 
  
const sub = (a, b) => a - b; 
  
const add1 = a => a + 1;