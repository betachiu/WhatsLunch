﻿// =============== 第一步: 確定我們的午餐資料回到前端了
const url = "https://my-json-server.typicode.com/betachiu/WhatsLunch/items/";
const index = "1";

fetch(url + index)
.then(response => response.json())
.then(lunch => console.log(lunch));


// =============== 第二步: 將餐點名稱顯示在畫面上
// const url = "https://my-json-server.typicode.com/betachiu/WhatsLunch/items/";
// const index = "1";

// fetch(url + index)
// .then(response => response.json())
// .then(lunch => document.getElementById("lunch").innerText = lunch.name);


// =============== 最終步: 每次重新整理都會是不同的餐點
// const url = "https://my-json-server.typicode.com/betachiu/WhatsLunch/items/";
// const index = Math.ceil(Math.random()*7); // 使用 Math 內建函式產生亂數

// fetch(url + index)
// .then(response => response.json())
// .then(lunch => document.getElementById("lunch").innerText = lunch.name);