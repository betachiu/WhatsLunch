﻿const fruits = ["Banana", "Orange", "Apple", "Mango"];

// 取得項目
console.log(fruits[0]); // "Banana"
// 新增項目
fruits[4] = "Lemon";
// 修改項目
fruits[1] = "Guava";

console.log(fruits); // ["Banana", "Guava", "Apple", "Mango", "Lemon"]


// 經常使用的一些方法
console.log(fruits.length); // 5
fruits.push("Grape"); // 新增項目在最後面
fruits.pop(); // 將最後面的項目移除
fruits.forEach(fruit => console.log(fruit)); // 一個個把陣列中的東西取出來