// 1. 變數宣告: 目前在第幾張照片、總共有幾張照片
// 2. 函式宣告: 點擊的時候要做什麼? (換照片、換文字，數字要循環)
// 3. 點擊事件: 點擊 box 的時候，呼叫函式

var N = 1;
var total = 3;

function nextPhoto() {

    if (N < total) {
        N += 1;
    } else {
        N = 1;
    }

    document.getElementById("photo").src = "images/dog_" + N + ".jpg";
    document.getElementById("title").innerHTML = "第" + N + "張";
}

document.getElementById("box").onclick = nextPhoto;