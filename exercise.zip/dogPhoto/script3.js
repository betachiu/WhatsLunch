// function 先改成宣告變數的寫法
// 然後再改成 箭頭函式 的寫法

let N = 1;
const total = 3;

const nextPhoto = () => {

    if (N < total) {
        N += 1;
    } else {
        N = 1;
    }

    document.getElementById("photo").src = "images/dog_" + N + ".jpg";
    document.getElementById("title").innerHTML = "第" + N + "張";
}

document.getElementById("box").onclick = nextPhoto;