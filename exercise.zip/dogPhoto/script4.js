// 將類似的東西「抽出來」變成 陣列
// 陣列的起始索引是 0

let N = 1;
const total = 3;
const name = ["大毛", "兩毛", "三毛"];

const nextPhoto = () => {

    if (N < total) {
        N += 1;
    } else {
        N = 1;
    }

    document.getElementById("photo").src = "images/dog_" + N + ".jpg";
    document.getElementById("title").innerHTML = name[N-1];
}

document.getElementById("box").onclick = nextPhoto;