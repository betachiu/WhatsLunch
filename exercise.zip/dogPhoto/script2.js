// 固定不變的，使用 const 宣告
// 會變動的，使用 let 宣告

let N = 1;
const total = 3;

function nextPhoto() {

    if (N < total) {
        N += 1;
    } else {
        N = 1;
    }

    document.getElementById("photo").src = "images/dog_" + N + ".jpg";
    document.getElementById("title").innerHTML = "第" + N + "張";
}

document.getElementById("box").onclick = nextPhoto;