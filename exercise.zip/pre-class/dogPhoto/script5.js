// 將關連的變數放在同一個物件上，變成數值(property)
// 陣列裡面也可以放入物件

let N = 1;
const total = 3;
const dog1 = {
    src: "images/dog_1.jpg",
    name: "大毛"
};
const dog2 = {
    src: "images/dog_2.jpg",
    name: "兩毛"
};
const dog3 = {
    src: "images/dog_3.jpg",
    name: "三毛"
};
const dogs = [dog1, dog2, dog3];

const nextPhoto = () => {

    if (N < total) {
        N += 1;
    } else {
        N = 1;
    }

    document.getElementById("photo").src = dogs[N-1].src;
    document.getElementById("title").innerHTML = dogs[N-1].name;
}

document.getElementById("box").onclick = nextPhoto;