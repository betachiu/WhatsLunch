﻿var LadyGaga = "LadyGaga";

function Taiwan() { 
    // 在台灣 (Functional Scope)
    var FiveFiveSixSix = "5566";
    console.log(LadyGaga); // 嗯嗯這個我認識
    console.log(FiveFiveSixSix); // 嗯嗯這個我認識
}

// 在全球 (Global Scope)
console.log(LadyGaga); // 嗯嗯這個我認識
console.log(FiveFiveSixSix); // 嗯嗯?????