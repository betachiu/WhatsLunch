﻿const PI = 3.14159;
PI = 3; // error