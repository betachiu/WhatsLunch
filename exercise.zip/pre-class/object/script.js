﻿const car = {
	name: "TOYOTA",
	model: "500",
	weight: 850,
	color: "white",
	start: () => console.log("Car start"),
	drive: () => console.log("Car drive"),
	brake: () => console.log("Car brake"),
	stop: () => console.log("Car stop")
};

// 取得 property
console.log(car.name); // "TOYOTA"
console.log(car["name"]); // "TOYOTA"
// 使用 method
car.start();

// 錯誤示範
console.log(car[name]); // undefined
// 但是可以放變數
const key = "name";
console.log(car[key]); // "TOYOTA"
